//http://dummy.restapiexample.com/
import { Dashboard } from './layout/dashboard';
const dashboard = new Dashboard();


